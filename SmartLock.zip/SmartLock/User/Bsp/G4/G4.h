#ifndef __G4_H
#define	__G4_H

#include "stm32f10x.h"
#include <stdio.h>
#include <stdbool.h>

// ����4-UART4
#define  G4_USARTx                   USART3
#define  G4_USART_CLK                RCC_APB1Periph_USART3
#define  G4_USART_APBxClkCmd         RCC_APB1PeriphClockCmd
 #define  G4_USART_BAUDRATE           115200

// USART GPIO ���ź궨��
#define  G4_USART_GPIO_CLK           (RCC_APB2Periph_GPIOC)
#define  G4_USART_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  G4_USART_TX_GPIO_PORT       GPIOB  
#define  G4_USART_TX_GPIO_PIN        GPIO_Pin_10
#define  G4_USART_RX_GPIO_PORT       GPIOB
#define  G4_USART_RX_GPIO_PIN        GPIO_Pin_11

#define  G4_USART_IRQ                USART3_IRQn
#define  G4_USART_IRQHandler         USART3_IRQHandler


//�������
#define  G4_RST_PORT       GPIOB  
#define  G4_RST_PIN        GPIO_Pin_1

#define  G4_LIKA_PORT       GPIOB 
#define  G4_LIKA_PIN        GPIO_Pin_8

#define  G4_STAT_PORT       GPIOB 
#define  G4_STAT_PIN        GPIO_Pin_9




struct G4_UART_BUFF
{
	int16_t num;
	char data[1500]; 
};


#define RX_BUF_MAX_LEN     256                                     //�����ջ����ֽ���

extern struct  G4_USARTx_Fram                                  //��������֡�Ĵ����ṹ��
{
	char  Data_RX_BUF [ RX_BUF_MAX_LEN ];
	uint16_t FramLength;
	bool FramFinishFlag; 
} G4_Fram_Record;

void G4_StatePinConfig(void);
void G4_SendArray(uint8_t *array, uint16_t num);
void G4_SendString( char *str);
void G4_USART_Config(void);
bool G4_EnterATMode(void);
bool G4_ExitATMode(void);
bool G4_AT_RESTORE(void);
bool G4_AT_REBT(void);
bool G4_AT_UART_Query(uint32_t *baudrate,uint8_t *parity);
bool G4_AT_UART_Set(uint32_t baudrate,char *parity);
bool G4_AT_LINKSTA(uint8_t *sta);
bool G4_AT_SOCK(char *protocol,char *ip,char *port);
bool G4_AT_HEARTMOD(char *mode);
bool G4_AT_HEARTINFO(char *data);
bool G4_AT_HEARTM(uint32_t time);
bool G4_AT_UARTCLR(uint8_t flag);

bool G4_CheckSTAT(void);
bool G4_CheckLIKA(void);
void G4_RST(void);
#endif

