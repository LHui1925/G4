#ifndef __HANLE_code_H
#define __HANLE_code_H

#include <stm32f10x.h>
#include "rtthread.h"
#include "board.h"


void handle_FR(void);
void handle_sys(void);



#endif

